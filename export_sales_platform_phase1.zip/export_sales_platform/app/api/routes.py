from io import BytesIO
from fastapi import APIRouter,Depends,HTTPException,UploadFile,File,Request
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.schemas.lead import LeadCreate
from app.repositories.leads import LeadRepository
from app.services.configuration import qualification_config
from app.services.qualification import QualificationService
from app.services.research import WebsiteResearchService
from app.services.import_export import parse_upload,export_excel

r=APIRouter(prefix="/api")
def process(data,db,web=True):
    repo=LeadRepository(db); company=repo.upsert_company(data); product=qualification_config()["product"]["name"]; lead=repo.get_or_create_lead(company,product)
    text=""
    if web:
        text,ok,error=WebsiteResearchService().research(data.website); repo.add_research(lead,text,ok,error)
    score,classification,status,reasons,details=QualificationService().score(data,text); repo.replace_score(lead,score,classification,status,reasons,details); db.commit(); return lead
@r.post("/leads")
def create(data:LeadCreate,web_research:bool=True,db:Session=Depends(get_db)): return {"id":process(data,db,web_research).id}
@r.get("/leads")
def list_leads(status:str|None=None,classification:str|None=None,db:Session=Depends(get_db)):
    return [{"id":x.id,"company_name":x.company.name,"country":x.company.country,"website":x.company.website,"score":x.score,"classification":x.classification,"status":x.status,"reasons":x.reasons} for x in LeadRepository(db).list(status,classification)]
@r.get("/leads/{lead_id}")
def detail(lead_id:int,db:Session=Depends(get_db)):
    x=LeadRepository(db).get(lead_id)
    if not x: raise HTTPException(404,"Lead not found")
    return {"id":x.id,"company":{"name":x.company.name,"country":x.company.country,"website":x.company.website},"score":x.score,"classification":x.classification,"status":x.status,"reasons":x.reasons,"score_details":[{"rule":s.rule_name,"points":s.points,"evidence":s.evidence} for s in x.scores]}
@r.post("/imports")
async def import_file(file:UploadFile=File(...),web_research:bool=False,db:Session=Depends(get_db)):
    try: rows=parse_upload(file.filename or "leads.csv",await file.read())
    except ValueError as e: raise HTTPException(400,str(e))
    errors=[]; processed=0
    for i,row in enumerate(rows,2):
        try: process(row,db,web_research); processed+=1
        except Exception as e: db.rollback(); errors.append({"row":i,"error":str(e)[:250]})
    return {"processed":processed,"errors":errors}
@r.get("/exports/leads.xlsx")
def export(db:Session=Depends(get_db)):
    b=export_excel(LeadRepository(db).list()); return StreamingResponse(b,media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",headers={"Content-Disposition":"attachment; filename=qualified_leads.xlsx"})
@r.get("/summary")
def summary(db:Session=Depends(get_db)): return LeadRepository(db).summary()
