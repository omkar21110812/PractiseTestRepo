from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "Export Sales Platform"
    database_url: str = "sqlite:///./data/export_sales.db"
    config_path: str = "config/qualification.yaml"
    research_timeout_seconds: int = 12
    enable_web_research: bool = True
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
Path("data").mkdir(exist_ok=True)
