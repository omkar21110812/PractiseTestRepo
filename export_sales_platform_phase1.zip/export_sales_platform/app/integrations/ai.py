from abc import ABC, abstractmethod
class AIProvider(ABC):
    @abstractmethod
    def qualify(self,company_context:dict)->dict: ...
class DisabledAIProvider(AIProvider):
    def qualify(self,company_context): raise RuntimeError("AI is disabled in Phase 1")
