from abc import ABC, abstractmethod
class AutomationAdapter(ABC):
    @abstractmethod
    def publish(self,event_name,payload): ...
class DisabledAutomationAdapter(AutomationAdapter):
    def publish(self,event_name,payload): return False
