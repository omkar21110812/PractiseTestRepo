from abc import ABC, abstractmethod
class CRMAdapter(ABC):
    @abstractmethod
    def upsert_lead(self,lead): ...
class InternalCRMAdapter(CRMAdapter):
    def upsert_lead(self,lead): return lead.id
