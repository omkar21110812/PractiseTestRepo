from fastapi import FastAPI
from app.core.settings import settings
from app.core.database import Base,engine
from app.api.routes import r as api_router
from app.web.routes import r as web_router
from app import models
Base.metadata.create_all(engine)
app=FastAPI(title=settings.app_name,version="0.1.0")
app.include_router(api_router); app.include_router(web_router)
@app.get("/health")
def health(): return {"status":"ok","phase":1}
