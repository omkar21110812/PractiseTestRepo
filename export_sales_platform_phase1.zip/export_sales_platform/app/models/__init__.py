from app.models.entities import Company, Contact, Lead, ResearchResult, LeadScore, Activity
