from datetime import datetime
from sqlalchemy import String, Integer, Boolean, Text, DateTime, ForeignKey, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.core.database import Base

class Company(Base):
    __tablename__="companies"
    id: Mapped[int]=mapped_column(primary_key=True)
    name: Mapped[str]=mapped_column(String(240), index=True)
    country: Mapped[str]=mapped_column(String(100), default="")
    website: Mapped[str]=mapped_column(String(500), default="")
    business_type: Mapped[str]=mapped_column(String(200), default="")
    product_categories: Mapped[str]=mapped_column(Text, default="")
    imports_from_india: Mapped[bool]=mapped_column(Boolean, default=False)
    created_at: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    contacts: Mapped[list["Contact"]]=relationship(back_populates="company", cascade="all, delete-orphan")
    leads: Mapped[list["Lead"]]=relationship(back_populates="company", cascade="all, delete-orphan")
    __table_args__=(UniqueConstraint("name","website",name="uq_company_name_website"),)

class Contact(Base):
    __tablename__="contacts"
    id: Mapped[int]=mapped_column(primary_key=True)
    company_id: Mapped[int]=mapped_column(ForeignKey("companies.id"), index=True)
    name: Mapped[str]=mapped_column(String(200), default="")
    title: Mapped[str]=mapped_column(String(200), default="")
    email: Mapped[str]=mapped_column(String(320), default="")
    company: Mapped[Company]=relationship(back_populates="contacts")

class Lead(Base):
    __tablename__="leads"
    id: Mapped[int]=mapped_column(primary_key=True)
    company_id: Mapped[int]=mapped_column(ForeignKey("companies.id"), index=True)
    product_name: Mapped[str]=mapped_column(String(240))
    status: Mapped[str]=mapped_column(String(40), default="NEW", index=True)
    classification: Mapped[str]=mapped_column(String(20), default="")
    score: Mapped[int]=mapped_column(Integer, default=0, index=True)
    reasons: Mapped[str]=mapped_column(Text, default="")
    created_at: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    company: Mapped[Company]=relationship(back_populates="leads")
    research: Mapped[list["ResearchResult"]]=relationship(cascade="all, delete-orphan")
    scores: Mapped[list["LeadScore"]]=relationship(cascade="all, delete-orphan")

class ResearchResult(Base):
    __tablename__="research_results"
    id: Mapped[int]=mapped_column(primary_key=True)
    lead_id: Mapped[int]=mapped_column(ForeignKey("leads.id"), index=True)
    source: Mapped[str]=mapped_column(String(100), default="website")
    content: Mapped[str]=mapped_column(Text, default="")
    success: Mapped[bool]=mapped_column(Boolean, default=False)
    error: Mapped[str]=mapped_column(Text, default="")
    researched_at: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow)

class LeadScore(Base):
    __tablename__="lead_scores"
    id: Mapped[int]=mapped_column(primary_key=True)
    lead_id: Mapped[int]=mapped_column(ForeignKey("leads.id"), index=True)
    rule_name: Mapped[str]=mapped_column(String(100))
    points: Mapped[int]=mapped_column(Integer)
    evidence: Mapped[str]=mapped_column(Text, default="")

class Activity(Base):
    __tablename__="activities"
    id: Mapped[int]=mapped_column(primary_key=True)
    lead_id: Mapped[int|None]=mapped_column(ForeignKey("leads.id"), nullable=True, index=True)
    activity_type: Mapped[str]=mapped_column(String(80))
    detail: Mapped[str]=mapped_column(Text, default="")
    created_at: Mapped[datetime]=mapped_column(DateTime, default=datetime.utcnow)
