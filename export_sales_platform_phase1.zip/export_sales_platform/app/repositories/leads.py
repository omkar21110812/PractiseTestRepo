from sqlalchemy import select, func
from sqlalchemy.orm import Session, selectinload
from app.models import Company, Contact, Lead, ResearchResult, LeadScore, Activity

class LeadRepository:
    def __init__(self, db:Session): self.db=db
    def upsert_company(self,d):
        c=self.db.scalar(select(Company).where(Company.name==d.company_name,Company.website==d.website))
        if not c:
            c=Company(name=d.company_name,website=d.website); self.db.add(c)
        c.country=d.country; c.business_type=d.business_type; c.product_categories=d.product_categories; c.imports_from_india=d.imports_from_india
        self.db.flush()
        if d.contact_name or d.contact_email or d.contact_title:
            contact=self.db.scalar(select(Contact).where(Contact.company_id==c.id,Contact.email==d.contact_email))
            if not contact: self.db.add(Contact(company_id=c.id,name=d.contact_name,title=d.contact_title,email=d.contact_email))
        return c
    def get_or_create_lead(self,c,product):
        lead=self.db.scalar(select(Lead).where(Lead.company_id==c.id,Lead.product_name==product))
        if not lead: lead=Lead(company_id=c.id,product_name=product); self.db.add(lead); self.db.flush()
        return lead
    def replace_score(self,lead,score,classification,status,reasons,details):
        self.db.query(LeadScore).filter(LeadScore.lead_id==lead.id).delete()
        lead.score=score; lead.classification=classification; lead.status=status; lead.reasons="; ".join(reasons)
        for x in details: self.db.add(LeadScore(lead_id=lead.id,**x))
        self.db.add(Activity(lead_id=lead.id,activity_type="QUALIFIED",detail=f"{classification} ({score})"))
    def add_research(self,lead,content,success,error=""):
        self.db.add(ResearchResult(lead_id=lead.id,content=content,success=success,error=error))
    def list(self,status=None,classification=None):
        q=select(Lead).options(selectinload(Lead.company)).order_by(Lead.score.desc(),Lead.id.desc())
        if status: q=q.where(Lead.status==status)
        if classification: q=q.where(Lead.classification==classification)
        return list(self.db.scalars(q))
    def get(self,lead_id): return self.db.scalar(select(Lead).options(selectinload(Lead.company),selectinload(Lead.scores),selectinload(Lead.research)).where(Lead.id==lead_id))
    def summary(self):
        total=self.db.scalar(select(func.count(Lead.id))) or 0
        return {"total":total,"high":self.db.scalar(select(func.count(Lead.id)).where(Lead.classification=="HIGH")) or 0,"medium":self.db.scalar(select(func.count(Lead.id)).where(Lead.classification=="MEDIUM")) or 0,"low":self.db.scalar(select(func.count(Lead.id)).where(Lead.classification=="LOW")) or 0}
