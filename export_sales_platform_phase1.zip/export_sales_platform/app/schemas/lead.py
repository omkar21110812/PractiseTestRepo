from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field

class LeadCreate(BaseModel):
    company_name: str=Field(min_length=1, max_length=240)
    country: str=""
    website: str=""
    business_type: str=""
    product_categories: str=""
    imports_from_india: bool=False
    contact_name: str=""
    contact_title: str=""
    contact_email: str=""

class LeadRead(BaseModel):
    model_config=ConfigDict(from_attributes=True)
    id:int; product_name:str; status:str; classification:str; score:int; reasons:str; created_at:datetime
    company_name:str; country:str; website:str; business_type:str; product_categories:str
