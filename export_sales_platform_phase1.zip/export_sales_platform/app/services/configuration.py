from functools import lru_cache
import yaml
from app.core.settings import settings
@lru_cache
def qualification_config():
    with open(settings.config_path,encoding="utf-8") as f: return yaml.safe_load(f)
