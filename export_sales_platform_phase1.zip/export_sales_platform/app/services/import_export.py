from io import BytesIO
import pandas as pd
from app.schemas.lead import LeadCreate
COLUMNS=["company_name","country","website","business_type","product_categories","imports_from_india","contact_name","contact_title","contact_email"]
def parse_upload(name,content):
    ext=name.lower().rsplit(".",1)[-1]
    df=pd.read_excel(BytesIO(content),engine="openpyxl") if ext in {"xlsx","xlsm"} else pd.read_csv(BytesIO(content))
    missing=[c for c in COLUMNS if c not in df.columns]
    if missing: raise ValueError("Missing columns: "+", ".join(missing))
    out=[]
    for _,r in df.fillna("").iterrows():
        d={c:str(r[c]).strip() for c in COLUMNS}; d["imports_from_india"]=d["imports_from_india"].lower() in {"1","true","yes","y"}; out.append(LeadCreate(**d))
    return out
def export_excel(leads):
    rows=[{"lead_id":l.id,"company_name":l.company.name,"country":l.company.country,"website":l.company.website,"business_type":l.company.business_type,"product_categories":l.company.product_categories,"imports_from_india":l.company.imports_from_india,"score":l.score,"classification":l.classification,"status":l.status,"reasons":l.reasons} for l in leads]
    b=BytesIO(); pd.DataFrame(rows).to_excel(b,index=False,engine="openpyxl"); b.seek(0); return b
