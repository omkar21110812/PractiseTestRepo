from app.services.configuration import qualification_config
class QualificationService:
    @staticmethod
    def has(text,terms): return any(t in (text or "").lower() for t in terms)
    def score(self,data,website_text=""):
        cfg=qualification_config(); w=cfg["qualification"]["weights"]; result=[]
        def add(name,ok,points,evidence):
            if ok: result.append({"rule_name":name,"points":points,"evidence":evidence})
        target=cfg["product"]["target_country"].lower(); country=data.country.lower()
        add("target_country",target in country or country in {"usa","us","united states"},w["target_country"],data.country)
        blob=" ".join([data.business_type,website_text]).lower()
        add("distributor_or_importer",self.has(blob,["importer","distributor","wholesale","wholesaler"]),w["distributor_or_importer"],data.business_type)
        pblob=" ".join([data.product_categories,website_text]).lower()
        add("food_or_snack",self.has(pblob,["food","snack","grocery","healthy","vegetable"]),w["food_or_snack"],data.product_categories)
        add("imports_from_india",data.imports_from_india,w["imports_from_india"],"Provided import indicator")
        add("website_available",bool(data.website),w["website_available"],data.website)
        contact=bool(data.contact_email) or self.has(data.contact_title,["procurement","purchasing","buyer","sourcing","import"])
        add("procurement_contact",contact,w["procurement_contact"],data.contact_title or data.contact_email)
        score=min(sum(x["points"] for x in result),100); th=cfg["qualification"]["thresholds"]
        cls="HIGH" if score>=th["high"] else "MEDIUM" if score>=th["medium"] else "LOW"
        status={"HIGH":"QUALIFIED","MEDIUM":"REVIEW","LOW":"REJECTED"}[cls]
        return score,cls,status,[x["evidence"] for x in result],result
