import re, requests
from bs4 import BeautifulSoup
from app.core.settings import settings
from app.services.configuration import qualification_config
class WebsiteResearchService:
    def research(self,website):
        if not website: return "",False,"Website not supplied"
        url=website if website.startswith(("http://","https://")) else "https://"+website
        cfg=qualification_config()["research"]
        try:
            r=requests.get(url,timeout=settings.research_timeout_seconds,headers={"User-Agent":cfg["user_agent"]})
            r.raise_for_status(); soup=BeautifulSoup(r.text,"html.parser")
            for x in soup(["script","style","noscript"]): x.decompose()
            text=re.sub(r"\s+"," ",soup.get_text(" ",strip=True))[:cfg["max_text_chars"]]
            return text,True,""
        except requests.RequestException as e: return "",False,str(e)[:500]
