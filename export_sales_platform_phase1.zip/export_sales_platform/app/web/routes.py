from fastapi import APIRouter,Depends,Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.repositories.leads import LeadRepository
r=APIRouter(); templates=Jinja2Templates(directory="app/web/templates")
@r.get("/",response_class=HTMLResponse)
def dashboard(request:Request,db:Session=Depends(get_db)):
    repo=LeadRepository(db); return templates.TemplateResponse(request=request, name="dashboard.html", context={"summary":repo.summary(),"leads":repo.list()[:100]})
