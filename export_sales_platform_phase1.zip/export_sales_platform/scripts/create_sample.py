from pathlib import Path
import pandas as pd
Path("data").mkdir(exist_ok=True)
pd.DataFrame([{ "company_name":"Example Foods LLC","country":"United States","website":"","business_type":"Food importer and distributor","product_categories":"Healthy vegetable snacks","imports_from_india":"yes","contact_name":"A Buyer","contact_title":"Purchasing Manager","contact_email":"buyer@example.invalid"}]).to_excel("data/sample_leads.xlsx",index=False,engine="openpyxl")
print("Created data/sample_leads.xlsx")
