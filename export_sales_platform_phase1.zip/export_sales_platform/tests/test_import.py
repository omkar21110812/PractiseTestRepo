from app.services.import_export import COLUMNS
def test_columns_stable(): assert "company_name" in COLUMNS and "imports_from_india" in COLUMNS
