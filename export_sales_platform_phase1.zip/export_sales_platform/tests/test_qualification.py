from app.schemas.lead import LeadCreate
from app.services.qualification import QualificationService
def test_high_quality_lead():
    x=LeadCreate(company_name="Test Foods",country="United States",website="example.com",business_type="Food importer and distributor",product_categories="Healthy snacks",imports_from_india=True,contact_title="Purchasing Manager")
    score,classification,status,_,_=QualificationService().score(x,"")
    assert score==100 and classification=="HIGH" and status=="QUALIFIED"
